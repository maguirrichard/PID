import tkinter as tk
from tkinter import *
from tkinter import filedialog as dlg
from tkinter import ttk
import cv2
import glob
from glob import glob
import numpy as np
import PIL
from PIL import Image, ImageTk
import skimage as sk
from skimage.feature import greycomatrix, greycoprops #funcao do pacote skimage para calcular a matriz GLCM e os atributos da matriz
from skimage.io import imread #importando a funcao imread para leitura da imagem
from random import sample
import time
from skimage.color import rgb2gray #importando funcao rgb2grey que converte a imagem para cinza
from sklearn.metrics.cluster import entropy
from skimage import img_as_uint
import os.path
import matplotlib.pyplot as plt
import scipy
import random
import tensorflow as tf
from matplotlib import image
from sklearn.metrics import confusion_matrix
from tensorflow.keras import datasets,layers,models,metrics,callbacks
from keras.callbacks import ModelCheckpoint,EarlyStopping
from keras.models import load_model

#Inicialização do programa
root = Tk()
my_menu = Menu(root)

#Configurações da tela
root.config(menu=my_menu)
root.title('Trabalho Prático - PID')
root.geometry('1366x1024') 

#Inicialização do frame1
frame1 = Frame(root, width=1124, height=1024, background='white')
frame1.pack_propagate(0)    
frame1.pack(side="left")

#Inicialização do frame
frame = Frame(root, width=35, height=400)
frame.pack_propagate(0)
frame.pack(side="left")

#Inicialização do frame2
frame2 = Frame(root, width=130, height=130, background='white')
frame2.pack_propagate(0)    
frame2.pack(side="left")

#Declarações e inicialização de variáveis globais
img = 0
fname = ''
canvas = tk.Canvas(frame1, borderwidth=0, highlightthickness=0)
canvas2 = tk.Canvas(frame2, borderwidth=0, highlightthickness=0)
topx, topy= 0, 0
rect_id = None
lista_imagensB1=[]  #lista BIRADS I.
lista_imagensB2=[]  #lista BIRADS II.
lista_imagensB3=[]  #lista BIRADS III.
lista_imagensB4=[]  #lista BIRADS IV.
classificar=[]

def our_command():
   pass

def lerDiretorio():
   global lista_imagensB1, lista_imagensB2, lista_imagensB3, lista_imagensB4

   cont = 0

   path1 = "./imagens/1/*.*" #caminho pras pastas 
   path2 = "./imagens/2/*.*" #caminho pras pastas 
   path3 = "./imagens/3/*.*" #caminho pras pastas
   path4 = "./imagens/4/*.*" #caminho pras pastas 

   for arq in glob.glob(path1):   
       print('[' + str(cont) + '] ' + arq)     #printa os caminhos
       b1 = cv2.imread(arq)  #lê cada imagem
       lista_imagensB1.append(b1)  #Cria a lista com as imagens
       cont = cont + 1

   for arq in glob.glob(path2):   
       print('[' + str(cont) + '] ' + arq)     #printa os caminhos
       b2 = cv2.imread(arq)  #le cada imagem
       lista_imagensB2.append(b2)  #Cria a lista com as imagens
       cont = cont + 1

   for arq in glob.glob(path3):   
       print('[' + str(cont) + '] ' + arq)     #printa os caminhos
       b3 = cv2.imread(arq)  #le cada imagem
       lista_imagensB3.append(b3)  #Cria a lista com as imagens
       cont = cont + 1

   for arq in glob.glob(path4):   
       print('[' + str(cont) + '] ' + arq)     #printa os caminhos
       b4 = cv2.imread(arq)  #le cada imagem
       lista_imagensB4.append(b4)  #Cria a lista com as imagens
       cont = cont + 1
        
   #print(lista_imagensB1[99])
   #Visualizar imagens lidas dos diretorios
   c = Canvas(root, height=25, width=190, background="gray")
   c.pack()
   c.create_text(97,15,fill="black",font="Arial 12 bold", text= str(cont) + " imagens foram lidas")
   c.after(7000, lambda: c.destroy())
    
def selecionar():
   #Abre qualquer uma das imagens
   from matplotlib import pyplot as plt
   plt.imshow(lista_imagensB1[99])  
   plt.show()

def abrirImagem():
   global img, fname
   filename = dlg.askopenfilename() #selecionar um arquivo
   fname=filename;
   img = Image.open(filename)
   load = ImageTk.PhotoImage(img)
   canvas.config(width=load.width(), height=load.height())
   canvas.pack(expand=True)
   canvas.img = load
   canvas.create_image(0, 0, image=load, anchor=tk.NW)
   canvas.place(x=0,y=0)
   
def zoom_in():
   global img
   load = ImageTk.PhotoImage(img)
   width = load.width()*1.25
   height = load.height()*1.25
   img = img.resize((int(width), int(height)), Image.ANTIALIAS)
   load = ImageTk.PhotoImage(img)
   canvas.config(width=load.width(), height=load.height())
   canvas.pack(expand=True)
   canvas.img = load
   canvas.create_image(0, 0, image=load, anchor=tk.NW)
   canvas.place(x=0,y=0)

def zoom_out():
   global img
   load = ImageTk.PhotoImage(img)
   width = load.width()*0.75
   height = load.height()*0.75
   img = img.resize((int(width), int(height)), Image.ANTIALIAS)
   load = ImageTk.PhotoImage(img)
   canvas.config(width=load.width(), height=load.height())
   canvas.pack(expand=True)
   canvas.img = load
   canvas.create_image(0, 0, image=load, anchor=tk.NW)
   canvas.place(x=0,y=0)

def redefinir():
   global img, fname
   img = Image.open(fname)
   load = ImageTk.PhotoImage(img)
   canvas.config(width=load.width(), height=load.height())
   canvas.pack(expand=True)
   canvas.img = load
   canvas.create_image(0, 0, image=load, anchor=tk.NW)
   canvas.place(x=0,y=0)

def marcarRegiao():
   global rect_id
   #Cria o retangualo
   rect_id = canvas.create_rectangle(topx, topy, topx, topy, dash=(2,2), fill='', outline='green')
   canvas.bind('<Button-1>', get_mouse_posn)

def get_mouse_posn(event):
   global topy, topx, img
   topx, topy = event.x, event.y
   canvas.coords(rect_id, topx-64, topy-64, topx+64, topy+64)
   crop_rectangle = (topx-64, topy-64, topx+64, topy+64)
   crop_img = img.crop(crop_rectangle)
   load = ImageTk.PhotoImage(crop_img)
   canvas2.config(width=load.width(), height=load.height())
   canvas2.pack(expand=True)
   canvas2.img = load
   canvas2.create_image(0, 0, image=load, anchor=tk.NW)
   canvas2.place(x=1,y=1)
   crop_img = crop_img.save("save.png")
      

def calcular1():
   global fname
   print("Calcular e exibir as características")

   #inicia tempo de exec
   start_time = time.time()

   #image_path = "./imagens/1/p_d_left_cc(108).png" #endereco da imagem
   image = imread(fname) #leitura da imagem
   image_gray = rgb2gray(image) #transformar de RGB para nivel de cinza
   #distancia escolhida entre os pixels para fazer a relação da GLCM é 1
   #print(image_gray)
   props = np.zeros((7)) # vetor para armazenar atributos (no caso o vetor que identifica os dados do usuario)

   
   # Toplevel object which will  
   # be treated as a new window 
   newWindow = Toplevel(root) 
  
   # sets the title of the 
   # Toplevel widget 
   newWindow.title("Características") 
   newWindow.geometry("250x650") 

   for i in range(5):
      matrix = greycomatrix(image_gray,[2**i],[0]) #calculo da matriz em 0 graus
      props[0] = greycoprops(matrix, 'contrast') #calcula constraste
      #print( "Contraste: " + str(props[0]))
      props[1] = greycoprops(matrix, 'dissimilarity') #calcula a dissimilaridade
      #print("Dissimilaridade: " + str(props[1]))
      props[2] = greycoprops(matrix, 'homogeneity') #calcula homogeneidade
      #print("Homogeneidade: " + str(props[2]))
      props[3] = greycoprops(matrix, 'energy') #calcula energia
      #print("Energia: " + str(props[3]))
      props[4] = greycoprops(matrix, 'correlation') #calcula correlacao
      #print( "Correlacao: " + str(props[4]))
      props[5] = greycoprops(matrix, 'ASM') #calcula o segundo momento angular
      #print( "ASM: " + str(props[5]))
      props[6] = entropy(image_gray) #calcula entropia
      #print("Entropia: " + str(props[6]))
      Label(newWindow, 
         text = "Matriz de ocorrência: " + str(2**i) +
         "\nHomogeneidade: " + str("{:.4f}".format(props[2])) +
         "\nEntropia: " + str("{:.4f}".format(props[6])) +
         "\nEnergia: " + str("{:.4f}".format(props[3])) +
         "\nContraste: " + str("{:.4f}".format(props[0]))
         ).pack()

   # Calculate Moments
   moments = cv2.moments(image_gray)

   # Calculate Hu Moments
   huMoments = cv2.HuMoments(moments)
 
   # Log scale hu moments
   for i in range(0,7):
    huMoments[i] = -1* np.copysign(1.0, huMoments[i]) * np.log10(abs(huMoments[i]))

   print("Momentos invariantes de Hu:")
   print(huMoments)
   tempo = time.time() - start_time
   print("--- %s seconds ---" % (tempo))

   Label(newWindow, text = "\nMomentos invariantes Hu\n" + str(huMoments)).pack()
   Label(newWindow,text ="Tempo = "  + str("--- %s segundos ---" % "{:.4f}".format(tempo))).pack()

def calcular2():
   print("Calcular e exibir as características")

   #inicia tempo de exec
   start_time = time.time()

   #image_path = "./imagens/1/p_d_left_cc(108).png" #endereco da imagem
   image = imread("save.png") #leitura da imagem
   image_gray = rgb2gray(image) #transformar de RGB para nivel de cinza
   #distancia escolhida entre os pixels para fazer a relação da GLCM é 1
   #print(image_gray)
   props = np.zeros((7)) # vetor para armazenar atributos (no caso o vetor que identifica os dados do usuario)

   
   # Toplevel object which will  
   # be treated as a new window 
   newWindow = Toplevel(root) 
  
   # sets the title of the 
   # Toplevel widget 
   newWindow.title("Características") 
   newWindow.geometry("250x650") 

   for i in range(5):
      matrix = greycomatrix(image_gray,[2**i],[0]) #calculo da matriz em 0 graus
      props[0] = greycoprops(matrix, 'contrast') #calcula constraste
      #print( "Contraste: " + str(props[0]))
      props[1] = greycoprops(matrix, 'dissimilarity') #calcula a dissimilaridade
      #print("Dissimilaridade: " + str(props[1]))
      props[2] = greycoprops(matrix, 'homogeneity') #calcula homogeneidade
      #print("Homogeneidade: " + str(props[2]))
      props[3] = greycoprops(matrix, 'energy') #calcula energia
      #print("Energia: " + str(props[3]))
      props[4] = greycoprops(matrix, 'correlation') #calcula correlacao
      #print( "Correlacao: " + str(props[4]))
      props[5] = greycoprops(matrix, 'ASM') #calcula o segundo momento angular
      #print( "ASM: " + str(props[5]))
      props[6] = entropy(image_gray) #calcula entropia
      #print("Entropia: " + str(props[6]))
      Label(newWindow, 
         text = "Matriz de ocorrência: " + str(2**i) +
         "\nHomogeneidade: " + str("{:.4f}".format(props[2])) +
         "\nEntropia: " + str("{:.4f}".format(props[6])) +
         "\nEnergia: " + str("{:.4f}".format(props[3])) +
         "\nContraste: " + str("{:.4f}".format(props[0]))
         ).pack()

   # Calculate Moments
   moments = cv2.moments(image_gray)

   # Calculate Hu Moments
   huMoments = cv2.HuMoments(moments)
 
   # Log scale hu moments
   for i in range(0,7):
    huMoments[i] = -1* np.copysign(1.0, huMoments[i]) * np.log10(abs(huMoments[i]))

   print("Momentos invariantes de Hu:")
   print(huMoments)
   tempo = time.time() - start_time
   print("--- %s seconds ---" % (tempo))

   Label(newWindow, text = "\nMomentos invariantes Hu\n" + str(huMoments)).pack()
   Label(newWindow,text ="Tempo = "  + str("--- %s segundos ---" % "{:.4f}".format(tempo))).pack()

def load_dataset():
    x,y= [],[]
    labels = [np.array([1,0,0,0]),np.array([0,1,0,0]),np.array([0,0,1,0]),np.array([0,0,0,1])]
    for dir in [1,2,3,4]:
        for img in glob(f"imagens/{dir}/*"):
            
            x.append(caracterizar1(img))
            
            y.append(labels[dir-1])
    random.seed(6)
    random.shuffle(x)
    random.seed(6)
    random.shuffle(y)
    cutoff = int(len(x)//1.33)
    return np.array(x[:cutoff]),np.array(y[:cutoff]),np.array(x[cutoff:]),np.array(y[cutoff:]),

def read_image(file_path):
    img = image.imread(file_path)
    return img
def caracterizar1(image_name):

    descritores=[]
    # print(image_name)
    image = imread(image_name) #leitura da imagem
    image_gray = rgb2gray(image) #transformar de RGB para nivel de cinza
    #distancia escolhida entre os pixels para fazer a relação da GLCM é 1
    matrix = greycomatrix(image_gray,[1],[0]) #calculo da matriz em 0 graus
    
    for i in range(5):
        matrix = greycomatrix(image_gray,[2**i],[0])
        props = np.zeros((7)) # vetor para armazenar atributos (no caso o vetor que identifica os dados do usuario)
        props[0] = greycoprops(matrix, 'contrast') #calcula constraste
        descritores.append(props[0])
        props[1] = greycoprops(matrix, 'dissimilarity') #calcula a dissimilaridade
        descritores.append(props[1])
        props[2] = greycoprops(matrix, 'homogeneity') #calcula homogeneidade
        descritores.append(props[2])
        props[3] = greycoprops(matrix, 'energy') #calcula energia
        descritores.append(props[3])
        props[4] = greycoprops(matrix, 'correlation') #calcula correlacao
        descritores.append(props[4])
        props[5] = greycoprops(matrix, 'ASM') #calcula o segundo momento angular
        descritores.append(props[5])
        props[6] = entropy(image_gray) #calcula entropia
        descritores.append(props[6])

    return descritores
def treinar():
   start=time.time()
   train_set_x,train_set_y,test_set_x,test_set_y= load_dataset()
   global classificar

   train_set_x= np.expand_dims(train_set_x,axis=-1)
   test_set_x= np.expand_dims(test_set_x,axis=-1)
   classificar = test_set_x

   # print(train_set_x.shape)
   # print(train_set_y.shape)
   # print(test_set_x.shape)
   # print(test_set_y.shape)


   model = models.Sequential()
   # model.add(layers.Conv2D(32,(1,1), activation='relu', input_shape=(300,7,1)))
   # model.add(layers.MaxPooling2D((1,1)))
   # model.add(layers.Conv2D(64,(1,1), activation='relu'))
   # model.add(layers.MaxPooling2D((1,1)))
   # model.add(layers.Conv2D(64,(1,1), activation='relu'))
   # model.add(layers.MaxPooling2D((1,1)))
   # model.add(layers.Conv2D(64,(1,1), activation='relu'))
   # model.add(layers.MaxPooling2D((1,1)))
   # model.add(layers.Conv2D(64,(1,1), activation='relu'))

   model.add(tf.keras.Input(shape=(35,1)))
   model.add(layers.Dense(64,activation='relu'))
   model.add(layers.Dense(64,activation='relu'))
   model.add(layers.Dense(64,activation='relu'))
   model.add(layers.Dense(64,activation='relu'))
   model.add(layers.Flatten())
   model.add(layers.Dense(64,activation='relu'))
   model.add(layers.Dense(32,activation='relu'))
   model.add(layers.Dense(16,activation='relu'))
   model.add(layers.Dense(8,activation='relu'))
   model.add(layers.Dense(4,activation='sigmoid'))


   #Mostrar arquitetura do Modelo
   model.summary()


   filepath='Bestmodel.hdf5'

   callbacks = [EarlyStopping(monitor='loss',patience=3,restore_best_weights=True),ModelCheckpoint(filepath,monitor='loss',verbose=1,
                save_best_only=True,save_weights_only=False,mode='auto',save_freq=1)]


   model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.3),loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),metrics=['accuracy'])
   
   model.fit(train_set_x,train_set_y, batch_size=64, epochs=100,callbacks=callbacks,validation_data=(test_set_x,test_set_y))
   end= time.time()

   # Calculo da matriz de confusão do treino
   train_predict= model.predict(train_set_x)
   train_matrix = confusion_matrix(train_set_y.argmax(axis=1),train_predict.argmax(axis=1))
   tn,fp,fn,tp = confusion_matrix(train_set_y.argmax(axis=1),train_predict.argmax(axis=1), labels=[0,1]).ravel()
   print('Matriz de connfusão treino')
   print(train_matrix)
   print('Especificidade: ', tn/(tn+fp))

   #Calculo da matraz de confusão do teste
   test_predict= model.predict(test_set_x)
   test_matrix = confusion_matrix(test_set_y.argmax(axis=1),test_predict.argmax(axis=1))
   tn2,fp2,fn2,tp2 = confusion_matrix(test_set_y.argmax(axis=1),test_predict.argmax(axis=1), labels=[0,1]).ravel()
   print('Matriz de connfusão teste')
   print(test_matrix)
   print('Especificidade: ', tn/(tn+fp))

   # Calculo da precisão do treino
   predictTrain= np.argmax(train_predict,axis=1)
   keysTrain= np.argmax(train_set_y,axis=1)
   correct=0
   for i in range(predictTrain.shape[0]):
       if predictTrain[i]==keysTrain[i]:
           correct+=1
   print(f"Train Accuracy: {(correct/predictTrain.shape[0])*100}%")

   # Calculo da precisão do teste
   predictTest= np.argmax(test_predict,axis=1)
   keysTest= np.argmax(test_set_y,axis=1)
   correct2=0
   for i in range(predictTest.shape[0]):
       if predictTest[i]==keysTest[i]:
           correct2+=1

   print(f"Test Accuracy: {(correct2/predictTest.shape[0])*100}%")

   print("Tempo gasto: ", end-start)
   # Toplevel object which will  
   # be treated as a new window 
   newWindow = Toplevel(root) 
   # sets the title of the 
   # Toplevel widget 
   newWindow.title("Características") 
   newWindow.geometry("250x650")
   
   Label(newWindow, 
         text = "Matriz de connfusão treino: \n" + str(train_matrix) +
         "\nEspecificidade: " + str(tn/(tn+fp)) +
         "\nMatriz de confusão teste: \n" + str(test_matrix) +
         "\nEspecificidade: " + str(tn2/(tn2+fp2)) +
         "\nTrain Accuracy: " + str("{:.2f}".format((correct/predictTrain.shape[0])*100))+"%"+
         "\nTest Accuracy: " + str("{:.2f}".format((correct2/predictTest.shape[0])*100))+"%"+
         "\nTempo gasto: "+ str("{:.4f}".format(end-start)+" segundos")
         ).pack()



def classificar():
   global classificar
   model_path='Bestmodel.hdf5'
   model= load_model(model_path)
   prediction = model.predict(classificar) 

   for i in range(len(classificar)):
      print("Imagem "+str(i)+" na Classe: ", np.argmax(prediction[i])+1)

def classificar2():
   global fname
   model_path='Bestmodel.hdf5'
   x=[]
   model= load_model(model_path)
   x.append(np.array(caracterizar1(fname)))
   x= np.array(x)
   x= np.expand_dims(x,axis=-1)

   prediction = model.predict(x)

   # print("Classe: ", np.argmax(prediction1)+1)

   newWindow = Toplevel(root) 
   # sets the title of the 
   # Toplevel widget 
   newWindow.title("Características") 
   newWindow.geometry("250x150")
   Label(newWindow, 
         text = "\nImagem carregada da Classe : " + str(np.argmax(prediction)+1) 
         ).pack()

def classificar3():
   model_path='Bestmodel.hdf5'
   x=[]
   model= load_model(model_path)
   x.append(np.array(caracterizar1('save.png')))
   x= np.array(x)
   x= np.expand_dims(x,axis=-1)

   prediction = model.predict(x)

   # print("Classe: ", np.argmax(prediction1)+1)

   newWindow = Toplevel(root) 
   # sets the title of the 
   # Toplevel widget 
   newWindow.title("Características") 
   newWindow.geometry("350x150")
   Label(newWindow, 
         text = "\nImagem da área selecionada pertence a Classe : " + str(np.argmax(prediction)+1) 
         ).pack()

#Menu
arquivo_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="Arquivo", menu=arquivo_menu)
arquivo_menu.add_command(label="Adicionar Imagem", command=abrirImagem)
arquivo_menu.add_separator()
arquivo_menu.add_command(label="Sair", command=root.quit)

#Visualizacao
visualizacao_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="Visualização", menu=visualizacao_menu)
visualizacao_menu.add_command(label="Zoom In (25%)", command=zoom_in)
visualizacao_menu.add_command(label="Zoom Out (25%)", command=zoom_out)
visualizacao_menu.add_separator()
visualizacao_menu.add_command(label="Redefinir", command=redefinir)


#Opcoes
opcoes_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="Opções", menu=opcoes_menu)
opcoes_menu.add_command(label="Ler diretório de imagens", command=lerDiretorio)
opcoes_menu.add_command(label="Treinar 75%", command=treinar)
opcoes_menu.add_command(label="Classificar 25%", command=classificar)
opcoes_menu.add_command(label="Marcar a região de interesse", command=marcarRegiao)
opcoes_menu.add_command(label="Caracterizar imagem completa", command=calcular1)
opcoes_menu.add_command(label="Caracterizar área selecionada", command=calcular2)
opcoes_menu.add_command(label="Classificar imagem completa", command=classificar2)
opcoes_menu.add_command(label="Classificar área selecionada", command=classificar3)

root.mainloop()